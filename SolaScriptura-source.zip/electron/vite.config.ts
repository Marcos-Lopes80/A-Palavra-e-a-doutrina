import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tsconfigPaths from "vite-tsconfig-paths";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

// Standalone SPA build used to package the desktop (Electron) app.
// Outputs to electron/renderer-dist/ and uses relative asset paths so that
// it can be loaded via the file:// protocol inside Electron.
export default defineConfig({
  base: "./",
  plugins: [react(), tsconfigPaths(), tailwindcss()],
  root: path.resolve(__dirname),
  publicDir: path.resolve(__dirname, "../public"),
  build: {
    outDir: path.resolve(__dirname, "renderer-dist"),
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(__dirname, "index.html"),
    },
  },
});
