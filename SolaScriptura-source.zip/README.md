# A Palavra e a Doutrina — Sola Scriptura

Aplicativo desktop (Windows `.exe`) e web para leitura da **Bíblia Sagrada — tradução Almeida (domínio público)** com um **índice navegável de Teologia Sistemática**. Funciona **100% offline** após instalado.

> *"Sola Scriptura"* — A Palavra e a doutrina lado a lado, para estudo aprofundado.

---

## ✨ Funcionalidades

- 📖 **Bíblia Almeida completa** (Antigo e Novo Testamento) com leitura por capítulo
- 🔍 **Busca por palavra** em todos os versículos
- 📚 **Teologia Sistemática** — índice clássico dos *loci theologici* (Bibliologia, Teologia Própria, Cristologia, Pneumatologia, Antropologia, Hamartiologia, Soteriologia, Eclesiologia, Escatologia)
- 🎨 Tema **azul royal** com tipografia serifada para leitura confortável
- 🧭 Navegação direta entre Bíblia e Teologia (sem fechar o app)
- 💾 **Offline-first** — todo o texto bíblico embarcado no executável

---

## 🚀 Como executar

### Versão Desktop (Windows `.exe`)
1. Baixe o arquivo `SolaScriptura-win-x64.zip` (release).
2. Extraia em qualquer pasta.
3. Execute `SolaScriptura.exe`.

Não requer instalação de Node.js, navegador ou bibliotecas adicionais.

### Versão Web (desenvolvimento)
```bash
bun install
bun run dev
```
Acesse `http://localhost:3000`.

---

## 🛠️ Stack Técnica

- **Framework:** TanStack Start v1 (React 19 + Vite 7)
- **Roteamento:** TanStack Router (file-based) com `createMemoryHistory` no Electron
- **Estilo:** Tailwind CSS v4 + design tokens semânticos (oklch)
- **Desktop:** Electron + `@electron/packager`
- **Tipografia:** Cormorant Garamond (serif) + Inter (sans)

---

## 📦 Empacotando o `.exe`

```bash
# 1. Build da SPA para Electron
npx vite build --config electron/vite.config.ts

# 2. Empacotar para Windows
npx @electron/packager . "SolaScriptura" \
  --platform=win32 --arch=x64 \
  --out=electron-release --overwrite \
  --ignore='node_modules' --ignore='^/src' \
  --ignore='^/public' --ignore='^/electron-release'
```

O executável final fica em `electron-release/SolaScriptura-win32-x64/SolaScriptura.exe`.

---

## 📂 Estrutura do Projeto

```
├── electron/
│   ├── main.cjs              # Processo principal do Electron
│   ├── index.html            # Shell HTML para SPA
│   ├── vite.config.ts        # Build SPA específico
│   └── renderer-dist/        # Output do build SPA
├── public/data/
│   ├── biblia.json           # Texto bíblico Almeida completo
│   └── biblia-index.json     # Índice de livros/capítulos
├── src/
│   ├── routes/
│   │   ├── __root.tsx        # Layout raiz
│   │   ├── index.tsx         # Página inicial
│   │   ├── biblia.tsx        # Leitor bíblico + busca
│   │   └── teologia.tsx      # Índice de Teologia Sistemática
│   ├── components/PageHeader.tsx
│   ├── lib/
│   │   ├── bible.ts          # Loader e utilitários da Bíblia
│   │   └── theology.ts       # Dados dos loci teológicos
│   ├── electron-entry.tsx    # Entrada do Electron (memory history)
│   └── styles.css            # Design tokens (tema azul royal)
└── package.json
```

---

## 📜 Licença & Créditos

- **Texto bíblico:** Tradução **João Ferreira de Almeida** — *domínio público*
- **Conteúdo teológico:** Resumos dos *loci* clássicos da teologia cristã reformada — *uso livre*
- **Código:** MIT

---

## 👤 Autor

**Marcos Lopes** — [@Marcos-Lopes80](https://github.com/Marcos-Lopes80)

> *"Toda a Escritura é divinamente inspirada e proveitosa para ensinar..."* — 2 Timóteo 3:16
