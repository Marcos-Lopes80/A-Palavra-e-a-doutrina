export type Topic = { title: string; summary: string; refs?: string[] };
export type Locus = {
  id: string;
  title: string;
  greek: string;
  description: string;
  topics: Topic[];
};

export const theology: Locus[] = [
  {
    id: "prolegomena",
    title: "Prolegômenos",
    greek: "Prolegomena",
    description:
      "Considerações preliminares sobre a natureza, método e fontes da teologia.",
    topics: [
      { title: "Definição de teologia", summary: "Discurso ordenado a respeito de Deus e suas obras." },
      { title: "Fontes da teologia", summary: "Revelação geral e revelação especial; Escritura como norma normans." },
      { title: "Método teológico", summary: "Exegese, teologia bíblica, sistemática, histórica e prática." },
    ],
  },
  {
    id: "bibliologia",
    title: "Bibliologia",
    greek: "Doutrina das Escrituras",
    description: "Estudo da revelação, inspiração, autoridade, suficiência e perspicuidade da Bíblia.",
    topics: [
      { title: "Revelação geral e especial", summary: "Deus se manifesta na criação, providência e consciência, e de modo salvífico nas Escrituras.", refs: ["Sl 19", "Rm 1:18-20"] },
      { title: "Inspiração", summary: "As Escrituras foram sopradas por Deus por meio dos autores humanos.", refs: ["2Tm 3:16", "2Pe 1:20-21"] },
      { title: "Inerrância e infalibilidade", summary: "A Escritura, em seus autógrafos, é verdadeira em tudo o que afirma." },
      { title: "Cânon", summary: "Reconhecimento histórico dos livros inspirados do AT e NT." },
      { title: "Suficiência e perspicuidade", summary: "A Escritura é suficiente para fé e prática, e clara nas verdades essenciais." },
    ],
  },
  {
    id: "teologia-propria",
    title: "Teologia Própria",
    greek: "Doutrina de Deus",
    description: "A existência, atributos e Trindade do Deus vivo e verdadeiro.",
    topics: [
      { title: "Existência de Deus", summary: "Argumentos clássicos: cosmológico, teleológico, ontológico, moral." },
      { title: "Atributos incomunicáveis", summary: "Aseidade, imutabilidade, eternidade, onipresença, onisciência, onipotência." },
      { title: "Atributos comunicáveis", summary: "Santidade, justiça, bondade, amor, misericórdia, fidelidade.", refs: ["Êx 34:6-7"] },
      { title: "Trindade", summary: "Um só Deus em três pessoas: Pai, Filho e Espírito Santo.", refs: ["Mt 28:19", "2Co 13:13"] },
      { title: "Decretos de Deus", summary: "Plano eterno, sábio e santo de Deus que abrange todas as coisas." },
    ],
  },
  {
    id: "antropologia",
    title: "Antropologia",
    greek: "Doutrina do homem",
    description: "Origem, natureza, queda e condição do ser humano diante de Deus.",
    topics: [
      { title: "Imagem de Deus", summary: "O homem foi criado à imagem e semelhança de Deus.", refs: ["Gn 1:26-27"] },
      { title: "Constituição humana", summary: "Dicotomia e tricotomia; unidade da pessoa." },
      { title: "Pecado e queda", summary: "Origem, natureza, transmissão e consequências do pecado.", refs: ["Gn 3", "Rm 5:12-21"] },
      { title: "Aliança das obras", summary: "Relação original do homem com Deus em Adão." },
    ],
  },
  {
    id: "cristologia",
    title: "Cristologia",
    greek: "Doutrina de Cristo",
    description: "A pessoa e obra de Jesus Cristo, verdadeiro Deus e verdadeiro homem.",
    topics: [
      { title: "Pessoa de Cristo", summary: "União hipostática: duas naturezas em uma só pessoa.", refs: ["Jo 1:1-14", "Fp 2:5-11"] },
      { title: "Estados de Cristo", summary: "Humilhação e exaltação." },
      { title: "Ofícios", summary: "Profeta, sacerdote e rei." },
      { title: "Obra expiatória", summary: "Substituição penal, propiciação, redenção e reconciliação.", refs: ["Is 53", "Rm 3:21-26"] },
      { title: "Ressurreição e ascensão", summary: "Vitória sobre a morte e entronização à destra do Pai." },
    ],
  },
  {
    id: "pneumatologia",
    title: "Pneumatologia",
    greek: "Doutrina do Espírito Santo",
    description: "A pessoa, divindade e obra do Espírito Santo na criação, salvação e igreja.",
    topics: [
      { title: "Pessoa e divindade", summary: "Terceira pessoa da Trindade, plenamente Deus." },
      { title: "Obra na salvação", summary: "Regeneração, habitação, selo, garantia.", refs: ["Jo 3:5-8", "Ef 1:13-14"] },
      { title: "Dons espirituais", summary: "Capacitação para edificação do corpo de Cristo.", refs: ["1Co 12", "Rm 12"] },
      { title: "Fruto do Espírito", summary: "Caráter cristão produzido pelo Espírito.", refs: ["Gl 5:22-23"] },
    ],
  },
  {
    id: "soteriologia",
    title: "Soteriologia",
    greek: "Doutrina da salvação",
    description: "A aplicação da redenção: como Deus salva o pecador.",
    topics: [
      { title: "Eleição", summary: "Escolha graciosa de Deus em Cristo antes da fundação do mundo.", refs: ["Ef 1:3-14"] },
      { title: "Chamado e regeneração", summary: "Chamado eficaz e novo nascimento operado pelo Espírito." },
      { title: "Conversão", summary: "Arrependimento e fé em Cristo." },
      { title: "Justificação", summary: "Ato judicial de Deus que declara justo o pecador por causa de Cristo.", refs: ["Rm 3:21-26", "Rm 5:1"] },
      { title: "Adoção e santificação", summary: "Filiação e processo de conformação à imagem de Cristo." },
      { title: "Perseverança e glorificação", summary: "Os que são de Cristo são guardados até a glória final." },
    ],
  },
  {
    id: "eclesiologia",
    title: "Eclesiologia",
    greek: "Doutrina da igreja",
    description: "Natureza, marcas, governo, ordenanças e missão da igreja.",
    topics: [
      { title: "Natureza da igreja", summary: "Igreja universal e local; corpo, esposa e templo." },
      { title: "Marcas e atributos", summary: "Una, santa, católica e apostólica; pregação, sacramentos e disciplina." },
      { title: "Ordenanças", summary: "Batismo e Ceia do Senhor.", refs: ["Mt 28:18-20", "1Co 11:23-26"] },
      { title: "Governo e ministérios", summary: "Presbíteros e diáconos; pluralidade e serviço." },
      { title: "Missão", summary: "Adoração, discipulado, comunhão, serviço e evangelização." },
    ],
  },
  {
    id: "escatologia",
    title: "Escatologia",
    greek: "Doutrina das últimas coisas",
    description: "Estado intermediário, segunda vinda de Cristo, ressurreição, juízo e estado eterno.",
    topics: [
      { title: "Morte e estado intermediário", summary: "Separação do corpo e da alma; presença com o Senhor." },
      { title: "Segunda vinda", summary: "Retorno pessoal, visível e glorioso de Cristo.", refs: ["At 1:11", "1Ts 4:13-18"] },
      { title: "Ressurreição e juízo", summary: "Ressurreição dos mortos e juízo final diante de Cristo." },
      { title: "Estado eterno", summary: "Novos céus e nova terra; vida eterna e perdição.", refs: ["Ap 21-22"] },
    ],
  },
];
