export type Book = { abbrev: string; name: string; chapters: string[][] };
export type BibleIndex = { abbrev: string; name: string; chapters: number }[];

let cachedBible: Book[] | null = null;
let cachedIndex: BibleIndex | null = null;
let inflight: Promise<Book[]> | null = null;

function dataUrl(name: string): string {
  // Works both with the web build (served from /) and the Electron build
  // (loaded via file://) by resolving relative to the current document.
  if (typeof window === "undefined") return `/data/${name}`;
  return new URL(`data/${name}`, window.location.href).toString();
}

export async function loadBible(): Promise<Book[]> {
  if (cachedBible) return cachedBible;
  if (inflight) return inflight;
  inflight = fetch(dataUrl("biblia.json"))
    .then((r) => r.json())
    .then((d: Book[]) => {
      cachedBible = d;
      return d;
    });
  return inflight;
}

export async function loadIndex(): Promise<BibleIndex> {
  if (cachedIndex) return cachedIndex;
  const r = await fetch(dataUrl("biblia-index.json"));
  cachedIndex = await r.json();
  return cachedIndex!;
}

// Old Testament books are the first 39
export const OT_COUNT = 39;

export function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}
