import { Link } from "@tanstack/react-router";
import { Home, BookOpen, Library } from "lucide-react";

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const navLink =
    "inline-flex h-9 items-center gap-1.5 rounded-md px-3 text-sm font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-foreground";
  const activeProps = { className: navLink + " bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground" };
  return (
    <header className="border-b border-border bg-card/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className={navLink} aria-label="Início">
          <Home className="h-4 w-4" />
          <span className="hidden sm:inline">Início</span>
        </Link>
        <Link to="/biblia" className={navLink} activeProps={activeProps}>
          <BookOpen className="h-4 w-4" />
          <span className="hidden sm:inline">Bíblia</span>
        </Link>
        <Link to="/teologia" className={navLink} activeProps={activeProps}>
          <Library className="h-4 w-4" />
          <span className="hidden sm:inline">Teologia</span>
        </Link>
        <div className="ml-auto min-w-0 text-right">
          <h1 className="serif truncate text-lg leading-tight text-foreground sm:text-xl">
            {title}
          </h1>
          {subtitle && (
            <p className="truncate text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
      </div>
    </header>
  );
}
