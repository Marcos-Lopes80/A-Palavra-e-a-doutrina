import { Link, createFileRoute } from "@tanstack/react-router";
import { BookOpen, Library } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sola Scriptura — Bíblia Almeida + Teologia" },
      { name: "description", content: "Tela de abertura: escolha entre Bíblia Sagrada Almeida e Teologia Sistemática." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen" style={{ background: "var(--gradient-hero)" }}>
      <main className="mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-6 py-16 text-center">
        <p className="mb-4 text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Sola Scriptura
        </p>
        <h1 className="serif text-5xl leading-tight text-foreground sm:text-7xl">
          A Palavra <em className="text-primary">e</em> a doutrina
        </h1>
        <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
          Bíblia Sagrada na tradução Almeida (domínio público) lado a lado com um
          índice navegável de Teologia Sistemática para estudo aprofundado.
        </p>

        <div className="mt-12 grid w-full gap-5 sm:grid-cols-2">
          <Link
            to="/biblia"
            className="group rounded-xl border border-border bg-card p-8 text-left transition-all hover:-translate-y-1 hover:border-primary/40"
            style={{ boxShadow: "var(--shadow-soft)" }}
          >
            <BookOpen className="mb-4 h-8 w-8 text-primary" />
            <h2 className="serif text-2xl text-card-foreground">Bíblia Sagrada</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Leitura por capítulo, busca por palavra e navegação rápida — Antigo e
              Novo Testamento, tradução Almeida.
            </p>
            <span className="mt-4 inline-block text-sm font-medium text-primary group-hover:underline">
              Abrir leitor →
            </span>
          </Link>

          <Link
            to="/teologia"
            className="group rounded-xl border border-border bg-card p-8 text-left transition-all hover:-translate-y-1 hover:border-primary/40"
            style={{ boxShadow: "var(--shadow-soft)" }}
          >
            <Library className="mb-4 h-8 w-8 text-primary" />
            <h2 className="serif text-2xl text-card-foreground">Teologia Sistemática</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Índice clássico dos <em>loci</em> da teologia: Bibliologia, Teologia
              Própria, Cristologia, Soteriologia e mais.
            </p>
            <span className="mt-4 inline-block text-sm font-medium text-primary group-hover:underline">
              Explorar índice →
            </span>
          </Link>
        </div>

        <p className="mt-16 text-xs text-muted-foreground">
          Texto bíblico em domínio público · Tradução João Ferreira de Almeida
        </p>
      </main>
    </div>
  );
}
