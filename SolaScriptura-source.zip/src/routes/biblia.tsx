import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { PageHeader } from "@/components/PageHeader";
import { loadBible, loadIndex, normalize, OT_COUNT, type Book, type BibleIndex } from "@/lib/bible";

const searchSchema = z.object({
  b: fallback(z.string(), "gn").default("gn"),
  c: fallback(z.number().int().min(1), 1).default(1),
  q: fallback(z.string(), "").default(""),
});

export const Route = createFileRoute("/biblia")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Bíblia Sagrada — Almeida" },
      { name: "description", content: "Leia a Bíblia Sagrada na tradução Almeida com navegação por capítulo e busca." },
    ],
  }),
  component: BibliaPage,
});

function BibliaPage() {
  const { b, c, q } = Route.useSearch();
  const navigate = useNavigate({ from: "/biblia" });
  const [bible, setBible] = useState<Book[] | null>(null);
  const [index, setIndex] = useState<BibleIndex | null>(null);
  const [query, setQuery] = useState(q);

  useEffect(() => {
    loadIndex().then(setIndex);
    loadBible().then(setBible);
  }, []);

  const book = useMemo(() => bible?.find((x) => x.abbrev === b), [bible, b]);
  const totalChapters = book?.chapters.length ?? 0;
  const verses = book?.chapters[c - 1] ?? [];

  function go(nextB: string, nextC: number) {
    navigate({ search: (p) => ({ ...p, b: nextB, c: nextC }) });
  }

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    const raw = query.trim();
    if (!raw) return;
    // Try to parse as a reference: "Book", "Book 3", "Book 3:16"
    if (bible) {
      const m = raw.match(/^\s*(\d?\s?[\p{L}\.]+(?:\s[\p{L}\.]+)?)\s*(\d+)?(?::\d+)?\s*$/u);
      if (m) {
        const namePart = normalize(m[1].replace(/\./g, "").replace(/\s+/g, " ").trim());
        const chapter = m[2] ? Math.max(1, parseInt(m[2], 10)) : 1;
        const found = bible.find(
          (bk) => normalize(bk.name) === namePart || normalize(bk.abbrev) === namePart,
        );
        if (found) {
          const ch = Math.min(chapter, found.chapters.length);
          navigate({ search: () => ({ b: found.abbrev, c: ch, q: "" }) });
          setQuery("");
          return;
        }
      }
    }
    navigate({ search: (p) => ({ ...p, q: raw }) });
  }

  // Search results
  const results = useMemo(() => {
    if (!q || !bible) return [];
    const needle = normalize(q);
    const out: { book: Book; ci: number; vi: number; text: string }[] = [];
    for (const bk of bible) {
      bk.chapters.forEach((ch, ci) =>
        ch.forEach((v, vi) => {
          if (normalize(v).includes(needle)) out.push({ book: bk, ci, vi, text: v });
        }),
      );
      if (out.length > 200) break;
    }
    return out;
  }, [q, bible]);

  const bookMatches = useMemo(() => {
    if (!q || !bible) return [];
    const needle = normalize(q);
    return bible.filter(
      (bk) => normalize(bk.name).includes(needle) || normalize(bk.abbrev) === needle,
    );
  }, [q, bible]);

  return (
    <div className="min-h-screen">
      <PageHeader
        title={book ? `${book.name} ${c}` : "Bíblia Sagrada"}
        subtitle="Tradução Almeida · Domínio Público"
      />

      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[280px_1fr]">
        {/* Sidebar */}
        <aside className="space-y-4 lg:sticky lg:top-4 lg:self-start">
          <form onSubmit={submitSearch} className="relative">
            <button
              type="submit"
              aria-label="Buscar"
              className="absolute left-1 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <Search className="h-4 w-4" />
            </button>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar versículo…"
              className="h-10 w-full rounded-md border border-input bg-background pl-10 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none ring-ring focus:ring-2"
            />
          </form>

          <BookList index={index} current={b} onPick={(ab) => go(ab, 1)} />
        </aside>

        {/* Main */}
        <main className="min-w-0">
          {q ? (
            <SearchResults
              q={q}
              results={results}
              bookMatches={bookMatches}
              onOpen={(ab, ci) => {
                navigate({ search: () => ({ b: ab, c: ci + 1, q: "" }) });
                setQuery("");
              }}
              onClear={() => {
                setQuery("");
                navigate({ search: (p) => ({ ...p, q: "" }) });
              }}
            />
          ) : (
            <article>
              <ChapterNav
                book={book}
                chapter={c}
                total={totalChapters}
                onChange={(nc) => go(b, nc)}
              />
              <div className="mt-6 rounded-lg border border-border bg-card p-6 sm:p-8" style={{ boxShadow: "var(--shadow-soft)" }}>
                <h2 className="serif text-3xl text-card-foreground">
                  {book?.name} <span className="text-muted-foreground">{c}</span>
                </h2>
                <div className="mt-6 space-y-3 text-[1.05rem] leading-relaxed text-[color:var(--color-verse)]">
                  {verses.map((v, i) => (
                    <p key={i}>
                      <sup className="mr-1.5 select-none font-sans text-[0.7rem] font-semibold text-[color:var(--color-verse-num)]">
                        {i + 1}
                      </sup>
                      <span className="serif">{v}</span>
                    </p>
                  ))}
                  {!book && <p className="text-muted-foreground">Carregando…</p>}
                </div>
              </div>
              <ChapterNav
                book={book}
                chapter={c}
                total={totalChapters}
                onChange={(nc) => go(b, nc)}
                className="mt-6"
              />
            </article>
          )}
        </main>
      </div>
    </div>
  );
}

function ChapterNav({
  book,
  chapter,
  total,
  onChange,
  className = "",
}: {
  book?: Book;
  chapter: number;
  total: number;
  onChange: (c: number) => void;
  className?: string;
}) {
  if (!book) return null;
  return (
    <div className={`flex items-center justify-between gap-2 ${className}`}>
      <button
        onClick={() => onChange(Math.max(1, chapter - 1))}
        disabled={chapter <= 1}
        className="inline-flex h-9 items-center gap-1 rounded-md border border-border bg-card px-3 text-sm transition-colors hover:bg-muted disabled:opacity-40"
      >
        <ChevronLeft className="h-4 w-4" /> Anterior
      </button>
      <select
        value={chapter}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-9 rounded-md border border-input bg-background px-3 text-sm"
      >
        {Array.from({ length: total }, (_, i) => (
          <option key={i + 1} value={i + 1}>
            Capítulo {i + 1}
          </option>
        ))}
      </select>
      <button
        onClick={() => onChange(Math.min(total, chapter + 1))}
        disabled={chapter >= total}
        className="inline-flex h-9 items-center gap-1 rounded-md border border-border bg-card px-3 text-sm transition-colors hover:bg-muted disabled:opacity-40"
      >
        Próximo <ChevronRight className="h-4 w-4" />
      </button>
    </div>
  );
}

function BookList({
  index,
  current,
  onPick,
}: {
  index: BibleIndex | null;
  current: string;
  onPick: (abbrev: string) => void;
}) {
  if (!index) return <div className="text-sm text-muted-foreground">Carregando livros…</div>;
  const ot = index.slice(0, OT_COUNT);
  const nt = index.slice(OT_COUNT);
  return (
    <div className="rounded-lg border border-border bg-card">
      <Section title="Antigo Testamento" books={ot} current={current} onPick={onPick} />
      <div className="border-t border-border" />
      <Section title="Novo Testamento" books={nt} current={current} onPick={onPick} />
    </div>
  );
}

function Section({
  title,
  books,
  current,
  onPick,
}: {
  title: string;
  books: BibleIndex;
  current: string;
  onPick: (a: string) => void;
}) {
  return (
    <div className="p-3">
      <p className="px-2 pb-2 text-[0.7rem] font-semibold uppercase tracking-wider text-muted-foreground">
        {title}
      </p>
      <ul className="max-h-[40vh] overflow-y-auto lg:max-h-[36vh]">
        {books.map((b) => (
          <li key={b.abbrev}>
            <button
              onClick={() => onPick(b.abbrev)}
              className={`w-full rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                current === b.abbrev
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground hover:bg-muted"
              }`}
            >
              {b.name}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SearchResults({
  q,
  results,
  bookMatches,
  onOpen,
  onClear,
}: {
  q: string;
  results: { book: Book; ci: number; vi: number; text: string }[];
  bookMatches: Book[];
  onOpen: (abbrev: string, ci: number) => void;
  onClear: () => void;
}) {
  return (
    <section>
      <div className="flex items-center justify-between">
        <h2 className="serif text-2xl">
          Resultados para <em className="text-primary">"{q}"</em>
        </h2>
        <button onClick={onClear} className="text-sm text-muted-foreground hover:text-foreground">
          Limpar
        </button>
      </div>
      {bookMatches.length > 0 && (
        <div className="mt-4 rounded-md border border-primary/40 bg-primary/10 p-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-primary">Livros</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {bookMatches.map((bk) => (
              <button
                key={bk.abbrev}
                onClick={() => onOpen(bk.abbrev, 0)}
                className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Abrir {bk.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <p className="mt-4 text-sm text-muted-foreground">
        {results.length} ocorrência{results.length === 1 ? "" : "s"} no texto
        {results.length >= 200 ? " (mostrando primeiras 200)" : ""}
      </p>
      <ul className="mt-4 space-y-2">
        {results.map((r, i) => (
          <li key={i}>
            <button
              onClick={() => onOpen(r.book.abbrev, r.ci)}
              className="block w-full rounded-md border border-border bg-card p-4 text-left transition-colors hover:border-primary/40"
            >
              <p className="text-xs font-semibold uppercase tracking-wide text-primary">
                {r.book.name} {r.ci + 1}:{r.vi + 1}
              </p>
              <p className="serif mt-1 text-[1.02rem] text-card-foreground">{r.text}</p>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
