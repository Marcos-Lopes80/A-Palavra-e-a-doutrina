import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { theology, type Locus } from "@/lib/theology";
import { normalize } from "@/lib/bible";

export const Route = createFileRoute("/teologia")({
  head: () => ({
    meta: [
      { title: "Teologia Sistemática — Índice" },
      { name: "description", content: "Índice navegável dos loci clássicos da Teologia Sistemática." },
    ],
  }),
  component: TeologiaPage,
});

function TeologiaPage() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<Locus | null>(theology[0] ?? null);

  const filtered = useMemo(() => {
    if (!query.trim()) return theology;
    const n = normalize(query);
    return theology
      .map((l) => ({
        ...l,
        topics: l.topics.filter(
          (t) => normalize(t.title).includes(n) || normalize(t.summary).includes(n),
        ),
      }))
      .filter((l) => normalize(l.title).includes(n) || l.topics.length > 0);
  }, [query]);

  return (
    <div className="min-h-screen">
      <PageHeader title="Teologia Sistemática" subtitle="Índice clássico dos loci theologici" />

      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[300px_1fr]">
        <aside className="space-y-4 lg:sticky lg:top-4 lg:self-start">
          <div className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
              <Search className="h-4 w-4" />
            </span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar no índice…"
              className="h-10 w-full rounded-md border border-input bg-background pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none ring-ring focus:ring-2"
            />
          </div>

          <nav className="rounded-lg border border-border bg-card p-2">
            <ul>
              {filtered.map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() => setActive(l)}
                    className={`w-full rounded-md px-3 py-2 text-left text-sm transition-colors ${
                      active?.id === l.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    }`}
                  >
                    <span className="serif text-base">{l.title}</span>
                    <span className="ml-2 text-xs opacity-70">{l.greek}</span>
                  </button>
                </li>
              ))}
              {filtered.length === 0 && (
                <li className="px-3 py-2 text-sm text-muted-foreground">Nada encontrado.</li>
              )}
            </ul>
          </nav>
        </aside>

        <main>
          {active && (
            <article
              className="rounded-lg border border-border bg-card p-6 sm:p-8"
              style={{ boxShadow: "var(--shadow-soft)" }}
            >
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
                {active.greek}
              </p>
              <h2 className="serif mt-1 text-3xl text-card-foreground">{active.title}</h2>
              <p className="mt-3 text-muted-foreground">{active.description}</p>

              <div className="mt-8 space-y-6">
                {active.topics.map((t) => (
                  <section key={t.title} className="border-l-2 border-primary/30 pl-4">
                    <h3 className="serif text-xl text-card-foreground">{t.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{t.summary}</p>
                    {t.refs && t.refs.length > 0 && (
                      <p className="mt-2 text-xs text-primary">
                        Ver: {t.refs.join(" · ")}
                      </p>
                    )}
                  </section>
                ))}
              </div>
            </article>
          )}
        </main>
      </div>
    </div>
  );
}
