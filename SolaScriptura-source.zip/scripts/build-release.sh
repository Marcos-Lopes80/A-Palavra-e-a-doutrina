#!/usr/bin/env bash
# Build & empacota o Sola Scriptura como .exe (Electron) e prepara release.
#
# Uso:
#   ./scripts/build-release.sh                 # gera .exe + .zip em /mnt/documents
#   ./scripts/build-release.sh --lfs           # também faz git add via LFS
#   ./scripts/build-release.sh --gh-release v1.0.0  # cria GitHub Release (requer gh CLI)
#
# Pré-requisitos:
#   - bun ou npm instalados
#   - Para --lfs: git lfs install (uma vez)
#   - Para --gh-release: gh auth login

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

APP_NAME="SolaScriptura"
PLATFORM="${PLATFORM:-win32}"
ARCH="${ARCH:-x64}"
OUT_DIR="electron-release"
DOCS_DIR="/mnt/documents"
ZIP_NAME="${APP_NAME}-${PLATFORM}-${ARCH}.zip"

LFS_MODE=false
GH_TAG=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --lfs) LFS_MODE=true; shift ;;
    --gh-release) GH_TAG="$2"; shift 2 ;;
    *) echo "Opção desconhecida: $1"; exit 1 ;;
  esac
done

echo "▶ 1/4  Build do renderer (Vite + electron/vite.config.ts)"
npx vite build --config electron/vite.config.ts

echo "▶ 2/4  Empacotando Electron (${PLATFORM}/${ARCH})"
rm -rf "${OUT_DIR}/${APP_NAME}-${PLATFORM}-${ARCH}"
npx @electron/packager . "${APP_NAME}" \
  --platform="${PLATFORM}" --arch="${ARCH}" \
  --out="${OUT_DIR}" --overwrite \
  --ignore='node_modules' \
  --ignore='^/src' --ignore='^/public' \
  --ignore='^/electron-release'

echo "▶ 3/4  Compactando para ${ZIP_NAME}"
mkdir -p "${DOCS_DIR}"
rm -f "${DOCS_DIR}/${ZIP_NAME}"
( cd "${OUT_DIR}" && \
  ( command -v zip >/dev/null && zip -r "${DOCS_DIR}/${ZIP_NAME}" "${APP_NAME}-${PLATFORM}-${ARCH}" \
    || nix run nixpkgs#zip -- -r "${DOCS_DIR}/${ZIP_NAME}" "${APP_NAME}-${PLATFORM}-${ARCH}" ) )

SIZE=$(du -h "${DOCS_DIR}/${ZIP_NAME}" | cut -f1)
echo "✔ Pacote pronto: ${DOCS_DIR}/${ZIP_NAME} (${SIZE})"

echo "▶ 4/4  Pós-processamento"
if $LFS_MODE; then
  echo "  → Adicionando ZIP ao Git via LFS"
  git lfs install --local || true
  git lfs track "*.zip" >/dev/null
  cp "${DOCS_DIR}/${ZIP_NAME}" "./${ZIP_NAME}"
  git add .gitattributes "./${ZIP_NAME}"
  echo "  ✔ Pronto. Faça: git commit -m 'release ${APP_NAME}' && git push"
fi

if [[ -n "${GH_TAG}" ]]; then
  if ! command -v gh >/dev/null; then
    echo "  ✖ 'gh' CLI não encontrado. Instale: https://cli.github.com/"
    exit 1
  fi
  echo "  → Criando GitHub Release ${GH_TAG} com asset ${ZIP_NAME}"
  gh release create "${GH_TAG}" "${DOCS_DIR}/${ZIP_NAME}" \
    --title "${APP_NAME} ${GH_TAG}" \
    --notes "Build automático: ${APP_NAME} ${PLATFORM}-${ARCH}"
  echo "  ✔ Release ${GH_TAG} publicada."
fi

echo ""
echo "✅ Concluído."
echo "   Pacote: ${DOCS_DIR}/${ZIP_NAME}"
[[ -z "${GH_TAG}" && "$LFS_MODE" = false ]] && \
  echo "   Dica: rode com --gh-release vX.Y.Z para publicar como GitHub Release (recomendado, não consome LFS)."
